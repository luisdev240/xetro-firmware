# Pliki SD Momentum dla T-Embed CC1101

32 brakujące gry przebudowane dla procesora ESP32-S3 (Xtensa), nie oryginalne pliki ARM z Flippera.
Nie dodano ponownie obecnych w porcie gier: DOOM, Asteroids, BlackJack, Game 15,
Pong, Snake 2.0, Tetris oraz Tamagotchi. Dotychczasowe wersje pozostają bez zmian.
Skopiuj zawartość tego folderu do katalogu głównego karty SD, zachowując `apps`,
`apps_assets`. Gry znajdują się w `apps/Games`.
Pełna paczka `../sdcard.zip` zawiera także podstawowe pliki oficjalnej paczki
Sor3nt v2.0.0, przykłady i układy Bad KB, zasoby DOOM oraz trzy asset packi:
Swirl, Psyduck i Better-Pet. Rozpakuj zawartość ZIP-a bezpośrednio do katalogu
głównego karty, nie do dodatkowego folderu `sdcard`.

BT Trigger, PC Monitor, Air Arkanoid i Air Labyrinth zostały wykluczone na życzenie.
Przy aktualizowaniu istniejącej karty usuń ręcznie `apps/Bluetooth/bt_trigger.fap`,
`apps/Bluetooth/pc_monitor.fap`, `apps/Games/air_arkanoid.fap` i
`apps/Games/air_labyrinth.fap`. Samo rozpakowanie ZIP-a nie kasuje starych plików.
U2F jest aplikacją wbudowaną w firmware, a nie FAP-em. Generuje własne klucze
w pamięci NVS urządzenia; w paczce nie ma prywatnych kluczy ani liczników U2F.
Nie kasuj NVS urządzenia i zachowaj alternatywny sposób logowania.

## Wymagany firmware

Niektóre gry potrzebują rozszerzonej tabeli funkcji firmware przygotowanej razem
z tą paczką. Format FAP i wersja główna API pozostają bez zmian; dotychczasowe
aplikacje portu nie zostały usunięte. Zbudowany obraz: `../build_t_embed/furi_esp32.bin`.
Aktualizacja zgodności gier została wgrana na podłączony T-Embed 7 października 2026.
Przy użyciu paczki na innym urządzeniu trzeba także zaktualizować firmware.

Nowe narzędzia znajdują się w `apps/Tools` i `apps/Bluetooth`.
Ich zakres zgodności opisuje `tools-status.md`.

## Zakres sprawdzenia

Weryfikacja obejmuje kompilację, architekturę ESP32-S3, zależności względem rzeczywiście
zlinkowanego firmware i zgodność dwóch kopii paczki. Nie przeprowadzono jeszcze
testów rozgrywki wszystkich gier na fizycznym T-Embedzie.

- Quadrastic nie korzysta z nieobecnego na T-Embed czujnika Video Game Module.
- Laser Tag zawiera funkcje IR oraz dodatkowego sprzętu Flippera. Tryby wymagające
  nieobecnego na T-Embed sprzętu LF RFID/GPIO nie są potwierdzone jako działające.
- Synteza mowy Chess została dostosowana z PWM STM32 do I2S T-Embed; wymaga testu odsłuchu.
- Chess uruchomił się na urządzeniu według testu użytkownika.
  Quadrastic i Solitaire przebudowano dodatkowo bez nieużywanych
  tabel wyjątków z relokacjami PDIFF32, których loader nie obsługuje.

## Źródła i licencje

Źródło gier: https://github.com/Next-Flip/Momentum-Apps.
Zmiany wykonano wyłącznie w Flipper-Zero-ESP32-Port, bez modyfikowania Momentum-Firmware.
Kopie źródeł i ich licencje znajdują się w `../applications_user/momentum_games`;
istniejące wersje ESP32 wykorzystują swoje dotychczasowe katalogi w
`../applications_user`, a DOOM — `../applications/main/doom`.
Lista gier i wynik kompilacji: `games-build-report.csv`.
