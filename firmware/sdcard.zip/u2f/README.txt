U2F is built into this T-Embed Momentum firmware.
Open U2F from the main menu and accept its warnings.
The device generates and stores its own identity in NVS, not on SD.
No shared certificate keys, device keys or counters are supplied here.
Keep another login method; this experimental device can fail.
